#!/usr/bin/bash

sudo cp Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
